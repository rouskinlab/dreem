from enum import Enum

import numpy as np


class Alphabet(Enum):
    BLOCKS = " ░▒▓█"


def array_to_txt(array: np.ndarray, alphabet: Alphabet):
    pass
