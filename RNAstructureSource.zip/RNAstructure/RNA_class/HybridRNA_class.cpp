// HybridRNA_class.cpp : Defines the entry point for the console application.
//




int main(int argc, char* argv[])
{
	return 0;
}

