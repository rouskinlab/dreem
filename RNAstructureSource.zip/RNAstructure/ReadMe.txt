
This is the source code for RNAstructure, which includes tools for
RNA secondary structure prediction and analysis.

It is covered by the GNU GENERAL PUBLIC LICENSE Version 2 (see
gpl.txt for the full license).

----
Documentation and help can be accessed by opening the local file 
'Index.html' from inside the 'manual/html' directory.
It can also be found online at:
http://rna.urmc.rochester.edu/RNAstructureHelp.html
----

Please contact David Mathews with any question or comments:
David_Mathews@urmc.rochester.edu
