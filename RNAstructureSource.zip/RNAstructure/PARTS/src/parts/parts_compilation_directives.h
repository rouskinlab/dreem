#ifndef _COMPILATION_DIRECTIVES_
#define _COMPILATION_DIRECTIVES_

// These computations are defined separately from the single sequence partition function computations, so that
// single partition function and PARTS can work in different domains.
#define _LINEAR_COMPUTATIONS_
//#define _LOG_COMPUTATIONS_

#endif // _COMPILATION_DIRECTIVES_
