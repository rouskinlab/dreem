#ifndef _PATHS_
#define _PATHS_

#define TIME_OP_FP "times.txt"

// Dumping dir
#define DUMPING_DIR "."

#endif // _PATHS_
