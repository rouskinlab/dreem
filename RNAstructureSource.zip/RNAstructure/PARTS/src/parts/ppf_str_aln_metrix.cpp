#include <stdio.h>
#include <stdlib.h>

t_ppf_str_aln_metrix::t_ppf_str_aln_metrix(int _n_samples, int _N1, int _N2)
{
	this->n_samples = _n_samples;
	this->N1 = _N1;
	this->N2 = _N2;
}

