#pragma once
#include "plot.h"

class CDotPlotView :
	public CPlot
{
	DECLARE_DYNCREATE(CDotPlotView)
public:
	CDotPlotView(void);
	~CDotPlotView(void);
};
