//This is a copy of platform.cpp -- included to "play nice" with the text version of Dynalign

#include <afxwin.h>

//Microsoft Visual C++ Version
#if !defined(PLATFORM)
#define PLATFORM

#define sgifix //an sgi difference





#endif

