#include "stdafx.h"
#include "dotplotview.h"

IMPLEMENT_DYNCREATE(CDotPlotView, CScrollView)

CDotPlotView::CDotPlotView(void)
{
}

CDotPlotView::~CDotPlotView(void)
{
}
