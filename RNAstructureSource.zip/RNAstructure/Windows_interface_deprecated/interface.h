
//this is included by algorithm.cpp to provide the definition
//	of TProgressDialog:


#include "TProgressDialog.h"




