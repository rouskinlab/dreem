

//Microsoft Visual C++ Version
#if !defined(PLATFORM)
#define PLATFORM

#define sgifix //an sgi difference





#endif

