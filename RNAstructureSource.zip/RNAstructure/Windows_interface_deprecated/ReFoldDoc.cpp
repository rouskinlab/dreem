// ReFoldDoc.cpp: implementation of the CReFoldDoc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RNAstructure.h"
#include "ReFoldDoc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNCREATE(CReFoldDoc, CCTDoc)

CReFoldDoc::CReFoldDoc()
{

}

CReFoldDoc::~CReFoldDoc()
{

}
